/*
	+------------------------------------+
	| Name: Gollapudi N Lakshmi Narayana |
	| Roll: 190101037                    |
	| Run : Linux g++                    |
	+------------------------------------+
	Programming assignment4 - CS348
*/
#include <bits/stdc++.h>
#define pb push_back
using namespace std;

extern int yyparse(void);
extern FILE* yyin; 
vector<string> exceptionStrings; 
char* err;
string errorString;
vector<string> rkwrds; 

void read_rkwrds(void){
	ifstream laks;
	laks.open("rkwrds.txt");
	string temp;

	while( getline(laks,temp)){
		rkwrds.pb(string(temp));
	}
}


int main(int argv, char** argc){
	int s=0;
	string inpFileName = "input.txt";
	if(argv>1){
		inpFileName = "correct.txt";
	}
	FILE* inputStream = fopen(inpFileName.c_str(),"r"); 

	err = (char *)malloc(sizeof(char)*256); 
	err[0] = '\0';

	read_rkwrds();
	printf("Compilation had Begun\n");
	
	string tmp1 = "---- Parse is ", tmp2 = "uccessful ----\n";
	string suc = "S", uns = "Uns";
	yyin = inputStream; 
	if(!yyparse()){
		cout<<tmp1 << suc << tmp2;
	}else{
		cout<<tmp1 << uns << tmp2;
	}
	printf("Compilation finished\n");

	if(exceptionStrings.size()){
		printf("---- Errors ----\n");
		for(int i=0;i<exceptionStrings.size();i++){
			cout<<exceptionStrings[i]<<endl;
		}
	}
	else{
		cout<<"No Errors\n";
	}
	fclose(inputStream); 


	return 0;
}