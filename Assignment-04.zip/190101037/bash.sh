make run
./runme > cur.txt
DIFF=$(diff cur.txt output.txt)
if [ "$DIFF" != "" ]
then 
	echo "somethings wrong"
	cat cur.txt
else
	echo "same answer no differnce - Good to go.."	
fi