/*
	+------------------------------------+
	| Name: Gollapudi N Lakshmi Narayana |
	| Roll: 190101037                    |
	| Run : Linux g++                    |
	+------------------------------------+
	Programming assignment4 - CS348
*/



Contents of this folder
-----------------------
1. readme: contains the information about the contents of this folder,
		   about the implementation details and the functionalities
2. input.txt: contains the input required for running this code
3. rkwrds.txt: contains the reserved keywords used in the input, one per line
4. lex.l : the same lex specification made in the earlier assignment, with a small modification containing the error handling code
5. yacc.y : BNF rules of the language are specified in this yacc specification
6. main.cpp : This is the controller code that initializes the input pointers and specifies the identifiers and tokens in the lex and yacc specification. 
7. makefile: compiling and excecution commands are defined in the makefile
8. output.txt, cur.txt, bash.sh : are the files used for debugging. Not required for the evaluation. 
9. correct.txt: contains the correct input (without) any errros when compiled

Note: To run the correct input "./runme correct" or "./runme --put anything here--" any extra arguments will do take the input as correct.txt as input file and the output is correspoinds to no errors.



Compiling and running
---------------------
1. To compile and run the program, first create the executable (runme) and run it using	
  > make run
  > ./runme

2. To remove the intermediate files and clean the submission
  > make clean

3. To show the output for correct input
  > ./runme --anything--
  	ex: ./runme fun
  	ex: ./runme 234


Simplied Evaluation (optional)
-----------------------------
-> Since verifing word by word could be hectic at times. use the bash script written 
-> that first runs the program using the makefile and creates the excecutable, then it redirects the current output of the program to cur.txt.
-> Diff command is used to see the difference between the cur.txt and output.txt files
-> if the contents of these files are same then success message "same answer no differnce - Good to go.." is shown
-> Incase the outputs doesn't match it displays the fail message "something wrong" and shows the output text. 

Note: altering output files or any depedenct in that matter could generate failure status but might print the outputs correctly.

	}  Running the bash script for simplified eval
	}  -------------------------------------------
	}  > sh bash.sh
	}  > // output here (compares current output with correct output) #used during debugging



Error Handling
--------------
1. Syntax Errors: Foreign characters, grammar wrong mistakes, reserved keywords usages are dealt under this category. 
2. Semantic Errors: Variable type mismatches, duplicate declarations, undefined variables etc are dealt in this category. 


