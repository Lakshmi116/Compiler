Running the code
-----------------

name of the cpp file: 190101037_Assign01.cpp
input file name: input.txt
Environment: Linux g++

> g++ 190101037_Assign01.cpp -o runme
> ./runme

__________________________________________________

functions done by pass1() and pass2()
------------------------------------

pass 1 reads the input.txt file and produces intermediate.txt that contains the same
instructions that are given in the input.txt but each line starts with the 
corresponding hex addresses of the instruction

pass 2: once the intermediate.txt is produced, pass2 process the same and produces 
listing.txt, output.obj and caret.txt

1. listing.txt contains the instructions appended by their object code at the end of each line
2. output.obj contains the object code of the instructions in the format mentioned
3. caret.txt contains the object code in text format along with some ^ indicators to mention 
the start of the each object code or address. these charecters are held after each line of
object code line

