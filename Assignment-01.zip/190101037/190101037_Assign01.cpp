/*

Gollapudi N Lakshmi Narayana
Roll No: 190101037

Env: Linux C++ 

*/


#include<iostream>
#include<fstream>
#include<vector>
#include<array>
#include<string>
#include<map>
#include<iomanip>
#include <cstdlib>
#include<bits/stdc++.h>

using namespace std;

// Data structures that held data of instructions,
// objects codes, global variables and error flags
map<string, string> optable = {
	{"LDA",  "00"},
	{"LDX",  "04"},
	{"LDL",  "08"},
	{"STA",  "0C"},
	{"STX",  "10"},
	{"STL",  "14"},
	{"LDCH", "50"},
	{"STCH", "54"},
	{"ADD",  "18"},
	{"SUB",  "1C"},
	{"MUL",  "20"},
	{"DIV",  "24"},
	{"COMP", "28"},
	{"J",    "3C"},
	{"JLT",  "38"},
	{"JEQ",  "30"},
	{"JGT",  "34"},
	{"JSUB", "48"},
	{"RSUB", "4C"},
	{"TIX",  "2C"},
	{"TD",   "E0"},
	{"RD",   "D8"},
	{"WD",   "DC"}
};

map<string, int> symtab;

string label, opcode, operand, buffer, sp = "    ",programme_name;
int locctr = 0, start_addr, programme_length;
bool duplicate_label = false, invalid_operation = false;


// utility functions to fragment an instruction into parts
string rd_str(string s, int &i);
void reach_str(string s, int &i);

void read_instruction(string inst);

// utility functions used for conversions from Int to Hex, Hex to Int
int hexToInt(string s);
string inttoHex(int n);
string sInttoSHex(int n);

// utility function to read instructions in pass 2
void reflect_inst(string inst);
void makeLine(string s);

// definitions of pass 1 and pass 2
void pass1(void);
void pass2(void);


// main functions that reads the input.txt and produces intermediate.txt using pass 1
// pass 2 processes intermediate.txt and produces listing.txt, output.obj 
// and caret.txt (contianing the ^ indicators)
int32_t main(){
	pass1();
	pass2();
	return 0;
}

void pass1(void){
	ifstream in ("input.txt");
	ofstream out ("intermediate.txt");
	string inst = "";

	getline(in, inst);
	makeLine(inst);
	read_instruction(inst);

	if(opcode == "START"){
		start_addr = hexToInt(operand);
		locctr = start_addr;
		programme_name = label;
		out<< std::hex<<locctr;
		out<< sp << inst<<"\n";
	
		getline(in, inst);
		makeLine(inst);
		read_instruction(inst);
	}else{
		locctr = 0;
	}
	
	while(opcode!="END"){
		if(inst[0]=='.'){
			out<<inst<<"\n";
			getline(in,inst);
			makeLine(inst);
			read_instruction(inst);
			continue;
		}
		if(label.size()){
			if(symtab.find(label)!=symtab.end()){
				duplicate_label = true;
			}else{
				symtab[label] = locctr;
			}
		}

		out<< std::hex<<locctr;
		out<<sp<<inst<<"\n";

		if(optable.find(opcode)!=optable.end()){
			locctr+=3;
		}else if(opcode=="WORD"){
			locctr+=3;
		}else if(opcode=="RESW"){
			locctr+= 3*stoi(operand);
		}else if(opcode=="RESB"){
			locctr += stoi(operand);
		}else if(opcode=="BYTE"){
			if((operand[0]=='X'||operand[0]=='x') && operand[1] =='\''){
				locctr += 1;
			}else if((operand[0]=='c' || operand[0]=='C') && operand[1]=='\''){
				int n = operand.size();
				for(int i=2;i<n;i++){
					if(operand[i]=='\''){
						locctr+= (i-2);
						break;
					}
				}
			}
		}else{
			invalid_operation = true;
		}

		getline(in, inst);
		makeLine(inst);
		read_instruction(inst);
	}
	out<<sp<<sp<<inst<<"\n";
	programme_length = locctr-start_addr;
	in.close();
	out.close();
	return;
}

void pass2(void){
	ifstream in ("intermediate.txt");
	ofstream out ("output.obj");
	ofstream list ("listing.txt");
	ofstream caret ("caret.txt");

	string inst, object_str, record_tail = "",record = "", caret_str = "";
	bool no_object = false;

	getline(in, inst);
	makeLine(inst);
	reflect_inst(inst);

	if(opcode=="START"){
		list<< inst<<"\n";

		getline(in, inst);
		makeLine(inst);
		reflect_inst(inst);
	}
	record = "T";
	record += inttoHex(locctr);
	out<<"H";
	out<<std::left<<setw(6)<<programme_name;
	out<<std::right<<setw(6)<<setfill('0')<<std::hex<< start_addr;
	out<<std::right<<setw(6)<<setfill('0')<<std::hex<< programme_length<<"\n";

	caret<<"H";
	caret<<std::left<<setw(6)<<programme_name;
	caret<<std::right<<setw(6)<<setfill('0')<<std::hex<< start_addr;
	caret<<std::right<<setw(6)<<setfill('0')<<std::hex<< programme_length<<"\n";

	caret<<" ^"<<right<<setw(6)<<setfill(' ')<<"^"<<right<<setw(6)<<setfill(' ')<<"^"<<"\n";

	// on the fly 1
	int opcode_val,index_val, addr_val, object_val;
	while(opcode!="END"){
		// on the fly 2
		opcode_val = 0x000000;
		index_val = 0x000000;
		addr_val = 0x000000;
		object_val = 0x000000;
		object_str = "";

		if(inst[0]=='.'){
			list<<inst<<"\n";
			getline(in,inst);
			reflect_inst(inst);
			continue;
		}

		if(optable.find(opcode)!=optable.end()){

			if(record==""){
				record = "T"+inttoHex(locctr);
			}

			opcode_val = hexToInt(optable[opcode]);
			opcode_val<<=16;

			if(operand[operand.size()-2]==',' && operand[operand.size()-1]=='X'){
				index_val = 0x008000;
				operand = operand.substr(0,operand.size()-2);
			}

			if(operand[0]!='\0'){
				if(symtab.find(operand)!=symtab.end()){
					addr_val = symtab[operand];
				}
			}
			object_val = opcode_val + index_val + addr_val;
			list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
			list<<std::right<<setw(6)<<setfill('0')<<std::hex<<object_val<<"\n";

			object_str = inttoHex(object_val);

		}else if(opcode=="BYTE"){

			if(record==""){
				record = "T"+inttoHex(locctr);
			}

			object_val = 0;
			string operand_tail = "";
			if((operand[0]=='X' || operand[0]=='x') && operand[1]=='\''){
				operand_tail = operand.substr(2, operand.size()-3);
				object_val = hexToInt(operand_tail);
			}else if((operand[0]=='C' || operand[0]=='c') && operand[1]=='\''){
				for(int i=2;i<operand.size()-1;i++){
					object_val+= operand[i];
					object_val<<=8;
				}
				object_val>>=8;
			}
			list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
			list<<std::right<<setw(2)<<setfill('0')<<std::hex<<object_val<<"\n";

			object_str = sInttoSHex(object_val);

		}else if(opcode=="WORD"){

			if(record==""){
				record = "T"+inttoHex(locctr);
			}

			object_val = stoi(operand);
			list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
			list<<std::right<<setw(6)<<setfill('0')<<std::hex<<object_val<<"\n";

			object_str = inttoHex(object_val);
		}else{
			list<<left<<setfill(' ')<<setw(40)<<inst<<"\n";

			if(record_tail != ""){
				record += sInttoSHex(record_tail.size()/2);
				record += record_tail;

				caret_str = " ^     ^ ^" + caret_str.substr(0,caret_str.size()-1);

				out<<record<<"\n";

				caret<<record<<"\n";
				caret<<caret_str<<"\n";
				caret_str = "";

				record_tail = "";
				record ="";
			}

			getline(in,inst);
			makeLine(inst);
			reflect_inst(inst);
			continue;
		}
		
		if(object_str.size() + record_tail.size() > 60){
			record += sInttoSHex(record_tail.size()/2);
			record += record_tail;

			caret_str = " ^     ^ ^" + caret_str.substr(0,caret_str.size()-1);

			out<<record<<"\n";

			caret<<record<<"\n";
			caret<<caret_str<<"\n";

			record_tail = "";
			record = "T";
			record += inttoHex(locctr); 

			caret_str = "";
		}
		record_tail+=object_str;
		if(object_str.size()==6){
			caret_str += "     ^";
		}
		else if(object_str.size()==2){
			caret_str+=" ^";
		}
		
		getline(in, inst);
		makeLine(inst);
		reflect_inst(inst);
	}

	record+=sInttoSHex(record_tail.size()/2);
	record+=record_tail;
	out<<record<<"\n";

	caret<<record<<"\n";
	caret<<" ^     ^ ^"+caret_str.substr(0,caret_str.size()-1)<<"\n";

	list<<inst;
	out<<"E"<<std::right<<setw(6)<<setfill('0')<<std::hex<<start_addr;

	caret<<"E"<<std::right<<setw(6)<<setfill('0')<<std::hex<<start_addr<<"\n";
	caret<<" ^";

	in.close();
	out.close();
	caret.close();
	list.close();
	return;
}

string rd_str(string s, int &i){
	int n = s.size();
	string tmp = "";
	while(i<n && s[i]!=' ' && s[i]!='\t' && s[i]!='\n'){
		tmp+=s[i++];
	}
	return tmp;
}

void reach_str(string s, int &i){
	int n = s.size();
	while(i<n && (s[i]==' ' || s[i]=='\t'))i++;
}

void read_instruction(string inst){
	int i = 0, n = inst.size();
	label = rd_str(inst, i);
	reach_str(inst, i);
	opcode = rd_str(inst,i);
	reach_str(inst, i);
	operand = rd_str(inst, i);
}



int hexToInt(string s){
	if(s[0]=='.')return 0;
	int num;
	sscanf(s.c_str(), "%x", &num);
	return num;
}

string inttoHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(6)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}
string sInttoSHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(2)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}

void reflect_inst(string inst){
	int i=0, n = inst.size();
	locctr = hexToInt(rd_str(inst, i));
	i+=4;
	label = rd_str(inst, i);
	reach_str(inst,i);
	opcode = rd_str(inst,i);
	reach_str(inst,i);
	operand = rd_str(inst,i);

}

void makeLine(string s){
	int n = s.size();
	if(s[n-1]=='\n'){
		s = s.substr(0,n-1);
	}
}