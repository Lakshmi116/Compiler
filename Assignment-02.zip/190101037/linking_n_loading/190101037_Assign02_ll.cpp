// Name    : Gollapudi N Lakshmi Narayana
// Roll No : 190101037
// Env     : Linux g++
// 


#include <bits/stdc++.h>

using namespace std;

// external symbol table : {string symbol, bool type, int control_section}
struct EXTERNAL_SYMTAB{
	string symbol;
	int addr;
	int control_section;
}external_symtab[80];

// location counter table: {string section_name, int start_addr, int loc, int length}
struct LOCTAB{
	string section;
	int start_addr;
	int control_section;
	int len;
}loctab[40];

// final object_code table
struct OBJ{
	string obj;
	int addr;
};

vector<OBJ> obj_val;

// modification records table
struct MODIFICATION_TABLE{
	int locctr;
	bool operation;
	string label;
	int len;
}modtab[90];

// variables
int progaddr, csaddr, execaddr, cslen;
bool external_symtab_found = 0, loctab_found = 0, modtab_found = 0;
int external_symtab_cnt = 0, external_symtab_index = 0, loctab_cnt = 0, loctab_index = 0, curr_addr, prev_addr, start_addr;
int modtab_cnt = 0, modtab_index = 0, curr_section = 0;

string sp = "    ";
// string sp = "\t";
map<int, char> record_type_index = {
	{0, 'H'},
	{1, 'D'},
	{2, 'R'},
	{3, 'T'},
	{4, 'E'}
};

void search_external_symtab(string s, int csec){
	external_symtab_index = -1;
	external_symtab_found = false;
	for(int i=0;i<external_symtab_cnt;i++){
		if(external_symtab[i].control_section == csec){
			int t = i;
			if(external_symtab[t].symbol == s){
				external_symtab_index = t;
				external_symtab_found = true;
				break;
			}
		}
	}
	if(external_symtab_found)return;
}
void search_external_symtab1(string s){
	external_symtab_index = -1;
	external_symtab_found = false;
	for(int i=0;i<external_symtab_cnt;i++){
		int t = i;
		if(external_symtab[t].symbol == s){
			external_symtab_index = t;
			external_symtab_found = true;
			break;
		}
	}
	if(external_symtab_found)return;
}
void search_loctab(string section){
	loctab_found = false;
	loctab_index = -1;
	for(int i=0;i<loctab_cnt;i++){
		if(loctab[i].section == section){
			loctab_index = i<<1;
			loctab_index/=2;
			loctab_found = true;
			break;
		}
	}
	if(loctab_found)return;
}

void add_to_external_symtab(string symbol, int addr, int csec){
	external_symtab[external_symtab_cnt] = {symbol, addr, csec};
	external_symtab_cnt++;
	return;
}

void add_to_loctab(string pname, int len, int start_addr){
	curr_section++;
	loctab[loctab_cnt] = {pname, start_addr, curr_section, len};
	loctab_cnt++;
	return;
}

int hexToInt(string s){
	if(s[0]=='.')return 0;
	int num;
	sscanf(s.c_str(), "%x", &num);
	return num;
}

string inttoHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(6)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}
string sInttoSHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(2)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}
string bInttoBHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(8)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}
string mInttoMHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(4)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}

void make_line(string s){
	int n = s.size();
	if(s[n-1]=='\n'){
		s = s.substr(0,n-1);
	}
}

string strip(string p){
	string s =p;
	int n = s.size();
	int i=0;
	while(i<n && s[i]==' '){
		i++;
	}
	if(i==n){
		return "";
	}
	s = s.substr(i);
	n = s.size();
	i = n-1;
	while(i>=0 && s[i]==' '){
		i--;
	}
	s = s.substr(0,i+1);
	return s;
}

void pass1(void){
	ifstream in ("linker_input.txt");

	string inst = "";
	// no intermediate file so no output required

	// starting address is given by the operating system
	// here we manually input starting address for loading
	// from the terminal
	cout<<"Enter the START-ADDRESS of the program\n";
	cin>>progaddr;

	csaddr = progaddr;

	
	while(getline(in,inst)){
		char record_type = inst[0];
		if(record_type=='H'){

			string progname = "", cslen_str = "", addr_str = "";
			progname = strip(inst.substr(1, 6));
			addr_str = inst.substr(7,6);
			cslen_str = inst.substr(13, 6);

			cslen = hexToInt(cslen_str);

			search_loctab(progname);
			if(loctab_found){
				cout<<"Invalid PNAME\nTerminating Linking...\n";
				return;
			}else{
				add_to_loctab(progname, cslen, csaddr);
			}

			search_external_symtab1(progname);
			if(external_symtab_found){
				cout<<"Invalid header...\n";
				return;
			}else{
				// external_symtab[external_symtab_cnt] = {progname, csaddr, curr_section};
				// external_symtab_cnt++;
				add_to_external_symtab(progname, csaddr, curr_section);
			}


			getline(in,inst);
			make_line(inst);
			while(inst[0]!='E'){
				if(inst[0]=='D'){
					string symbol = "", addr = "";
					int t = 1, n = inst.size();
					// cout<<" inst: "<<inst<<" "<<"\n";
					while(t+12<=n){
						string tmp = inst;
						symbol = strip(tmp.substr(t,6));
						addr = tmp.substr(t+6,6);
						t+=12;

						search_external_symtab(symbol, curr_section);
						if(external_symtab_found){
							cout<<"Invalid EXTREF definition\n";
							return;
						}else{
							add_to_external_symtab(symbol, hexToInt(addr)+csaddr, curr_section);
						}
						// return;
					}
					// return;
				}
				getline(in, inst);
				make_line(inst);
			}
			csaddr += cslen;
		}
		// cout<<inst<<"\n";
		// if(curr_section==3){
		// 	in.close();
		// 	return;
		// }
	}

	in.close();

}

void pass2(void){
	ifstream in ("linker_input.txt");

	curr_section = 0;
	csaddr = progaddr;
	execaddr = progaddr;
	string inst;

	while(getline(in,inst)){
		char record_type = inst[0];
		if(record_type == 'H'){
			// header info
			string progname, cslen_str, addr_str;
			int trec_len;
			progname = inst.substr(1, 6);
			addr_str = inst.substr(7,6);
			cslen_str = inst.substr(13, 6);

			cslen = hexToInt(cslen_str);
			prev_addr = hexToInt(addr_str) + csaddr;

			getline(in,inst);
			make_line(inst);
			while(inst[0]!='E'){

				record_type = inst[0];
				if(record_type == 'T'){
					string trec_addr, trec_size;

					trec_addr = inst.substr(1,6);
					trec_size = inst.substr(7, 2);

					start_addr = hexToInt(trec_addr)+csaddr;
					curr_addr = prev_addr;

					trec_len = hexToInt(trec_size);

					for(int i=prev_addr;i<start_addr;i++){
						obj_val.push_back({"..", curr_addr});
						curr_addr++;
					}
					for(int i=0;i<trec_len;i++){
						string tmp = "**";
						tmp[0] = inst[2*i+9];
						tmp[1] = inst[2*i+10];
						obj_val.push_back({tmp, curr_addr});
						curr_addr++;
					}
					prev_addr = curr_addr;
				}else if(record_type == 'M'){

					string mrec_addr, mrec_size;

					mrec_addr = inst.substr(1,6);
					mrec_size = inst.substr(7,2);



					modtab[modtab_cnt] = {hexToInt(mrec_addr) + csaddr, inst[9]=='+', inst.substr(10), hexToInt(mrec_size)};
					modtab_cnt++;
					// cout<<modtab[modtab_cnt-1].label;
					// cout<<" "<<modtab[modtab_cnt-1].locctr<<"\n";

				}

				getline(in,inst);
				make_line(inst);
			}
			if(inst.size()>1 &&  inst[0]=='E'){
				execaddr = csaddr + hexToInt(inst.substr(1,6));
			}
			csaddr += cslen;

		}
	}
	int xx_i = 29;
	while(xx_i--){
		obj_val.push_back({"xx", curr_addr});
		curr_addr++;
	}

	// for(auto x:obj_val){
	// 	cout<<x.obj<<" "<<x.addr<<"\n";
	// }


	// Modification records
	for(int i=0;i<modtab_cnt;i++){
		// cout<<i<<" "<<modtab[i].label<<"\n";
		int mloc = modtab[i].locctr - progaddr;

		search_external_symtab1(modtab[i].label);

		string tmp = "";
		for(int j=0;j<modtab[i].len;j+=2){
			tmp+=obj_val[mloc].obj;
			mloc++;
		}
		// cout<<tmp<<"\n";

		long int maddr = 0;
		if(tmp[0]=='F'){
			maddr = (long int)0xFFFFFFFF000000;
		}

		if(modtab[i].operation){
			maddr += strtol(tmp.c_str(), NULL, 16);
			maddr += (long int)external_symtab[external_symtab_index].addr;
		}else{	
			maddr += strtol(tmp.c_str(), NULL, 16);
			maddr -= (long int)external_symtab[external_symtab_index].addr;
		}
		// cout<<madd./r<<"\n";


		
		stringstream lak;
		lak << hex<<maddr;
		tmp = lak.str();
		string zros = "";
		while(tmp.size() < modtab[i].len)tmp= "0"+tmp;

		if(tmp.size()>6){
			tmp = tmp.substr(tmp.size()-6,6);
		}
		// cout<<tmp<<"\n";

		mloc = modtab[i].locctr - progaddr;
		// cout<<mloc<<"\n";
		int k = 0;
		for(int j=0;j<modtab[i].len;j+=2){
			obj_val[mloc].obj[0] = toupper(tmp[k]);
			obj_val[mloc].obj[1] = toupper(tmp[k+1]);
			mloc++;
			k+=2;
		}

	}
	in.close();
	// output file
	// --------------------------------------------------------------------
	ofstream out ("linker_loader_output.txt");

	out<<right<<setw(4)<<setfill('0')<<hex<<progaddr-16<<sp;
	out<<"xxxxxxxx    xxxxxxxx    xxxxxxxx    xxxxxxxx\n";

	int n = obj_val.size();
	int sp_cnt = 0;
	for(int i=0;i<n;i++){
		if(i==0){
			out<<right<<setw(4)<<setfill('0')<<hex<<obj_val[0].addr<<sp;
		}else if(i%16==0){
			out<<"\n";
			out<<right<<setw(4)<<setfill('0')<<hex<<obj_val[i].addr<<sp;
		}
		out<<obj_val[i].obj;
		sp_cnt++;
		if(!(sp_cnt-4)){
			out<<sp;
			sp_cnt = 0;
		}
	}
	out.close();
	// ---------------------


	ifstream inp ("linker_loader_output.txt");
	string nl;
	while(getline(inp, nl)){
		cout<<nl<<"\n";
	}
	inp.close();
}


int32_t main(void){

	pass1();
	pass2();
	return 0;
}