Name    : Gollapudi N Lakshmi Narayana
Roll No : 190101037
Env     : Linux g++


Assembler ::
------------------------------------------------
190101037_Assign02_assembler.cpp is the c++ file that contains all the code 
for assembler that suppports SICXE machine. the input.txt file in the same 
directory acts as the input and source code creates 
[intermediate.txt, listing.txt, object.txt, caret.txt] as outputs

-> object.txt contains all the object code
-> caret.txt contains the same object code with added ^ characters where
   ever nessasary to enable effective reading of values
-> listing contains the instructions given along with their object code 
   values in the right of each line where ever nessasary 
-> pass1(), pass2() and the utility functions does the same job as assembler for
   SIC but now could handle extra formats of instructions (2,3,4).
-> New record types [Modification, Define, refer] are handled.

Running :
+-------------------------------------------------+
| > g++ 190101037_Assign02_assembler.cpp -o runme |
| > ./runme                                       |
|                                                 |
| -- output here                                  |
+-------------------------------------------------+


Linking and Loading ::
------------------------------------------------
190101037_Assig02_ll.cpp contains the source code that takes an object code 
as input and produces the linked instruction hex code. This takes 
[linker_input.txt, STARTADDR] and produces [linker_loader_output.txt] as output

-> Linking and Loading changes the addresses relative to the STARTADDR 
   given manually by the user (normally operating system gives the 
   starting address for allocation). 
-> Use 16348 (0x4000) to get the intended outputfile
-> All the defined references are stored in the pass1()
-> In pass2() These references are prompted for modification of the object values.
-> Finally after performing the arthematic operations at specified locations in 
   the modified records all the instructions are now printed into 
   linker_loader_ouput.txt file with the same conventions followed in the book.

Running :
+-------------------------------------------------+
| > g++ 190101037_Assign02_ll.cpp -o runme        |
| > ./runme                                       |
| > 16384                                         |
|                                                 |
| -- output here                                  |
+-------------------------------------------------+