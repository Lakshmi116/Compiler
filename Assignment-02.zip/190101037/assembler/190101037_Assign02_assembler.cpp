// Name    : Gollapudi N Lakshmi Narayana
// Roll No : 190101037
// Run environment: Linux g++
// 



#include <bits/stdc++.h>

using namespace std;

map <string, string> optable = {
	{"LDA",  "00"},
	{"LDX",  "04"},
	{"LDL",  "08"},
	{"LDB",  "68"},
	{"LDT",  "74"},
	{"STA",  "0C"},
	{"STX",  "10"},
	{"STL",  "14"},
	{"LDCH", "50"},
	{"STCH", "54"},
	{"ADD",  "18"},
	{"SUB",  "1C"},
	{"MUL",  "20"},
	{"DIV",  "24"},
	{"COMP", "28"},
	{"COMPR","A0"},
	{"CLEAR","B4"},
	{"J",    "3C"},
	{"JLT",  "38"},
	{"JEQ",  "30"},
	{"JGT",  "34"},
	{"JSUB", "48"},
	{"RSUB", "4C"},
	{"TIX",  "2C"},
	{"TIXR", "B8"},
	{"TD",   "E0"},
	{"RD",   "D8"},
	{"WD",   "DC"},
};

// symtab : {string name, int addr, bool type, int control_section}
struct SYMTAB{
	string symbol;
	int addr;
	bool type;
	int control_section;
}symtab[30];

// redister table: {char symbol, int val}
map<char, int> reg = {
	{'A', 0},
    {'X', 1},
    {'L', 2},
    {'B', 3},
    {'S', 4},
    {'T', 5},
    {'F', 6}
};

// Modification records, indexes:
vector<string> modification_record;
int start_mod = -1;

// external symbol table : {string symbol, bool type, int control_section}
struct EXTERNAL_SYMTAB{
	string symbol;
	bool type;
	int control_section;
}external_symtab[30];

// literal table : {string name, int addr, int operand, int length}
struct LITTAB{
	string literal;
	int addr;
	int operand;
	int len;
}littab[40];

// location counter table: {string section_name, int start_addr, int loc, int length}
struct LOCTAB{
	string section;
	int start_addr;
	int loc;
	int len;
}loctab[40];


// variables
string label="", opcode = "" , operand = "", sp="    ";
int curr_section = 0, loctab_cnt = 0, symtab_index, external_symtab_cnt, symtab_cnt, littab_index, littab_cnt;
bool symtab_found = false, littab_found = false, invalid_operation=false;
int locctr = 0;

// ------------------------
void make_line(string s){
	int n = s.size();
	if(s[n-1]=='\n'){
		s = s.substr(0,n-1);
	}
}

string rd_str(string s, int &i){
	int n = s.size();
	string tmp = "";
	while(i<n && s[i]!=' ' && s[i]!='\t' && s[i]!='\n'){
		tmp+=s[i++];
	}
	return tmp;
}

void reach_str(string s, int &i){
	int n = s.size();
	while(i<n && (s[i]==' ' || s[i]=='\t'))i++;
	return;
}


void read_instruction(string s){
	int i=0, n = s.size();
	label = rd_str(s, i);
	reach_str(s, i);
	opcode = rd_str(s, i);
	reach_str(s,i);
	operand = rd_str(s,i);
}

int hexToInt(string s){
	if(s[0]=='.')return 0;
	int num;
	sscanf(s.c_str(), "%x", &num);
	return num;
}

string inttoHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(6)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}
string sInttoSHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(2)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}
string bInttoBHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(8)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}
string mInttoMHex(int n){
	std::stringstream sstream;
	sstream<<std::right<< setw(4)<<setfill('0')<<std::hex<<n;
	std::string s = sstream.str();
	return s;
}

void search_symtab(string s){
	symtab_index = -1;
	symtab_found = false;
	for(int i=0;i<symtab_cnt;i++){
		if(symtab[i].symbol == s && symtab[i].control_section == curr_section){
			symtab_found = true;
			symtab_index = i;
			break;
		}
	}
}
void search_littab(string s){
	littab_index = -1;
	littab_found = 0;
	for(int i=0;i<littab_cnt;i++){
		if(littab[i].literal == s){
			littab_found = 1;
			littab_index = i;
			return;
		}
	}
	return;
}
void add_to_symtab(string s){
	// symtab_found = 0;
	// symtab[symtab_cnt].symbol = s;
	// symtab[symtab_cnt].addr = loctab[curr_section].loc;
	// symtab[symtab_cnt].type = false;
	// symtab[symtab_cnt].control_section = curr_section;
	symtab[symtab_cnt] = {s, loctab[curr_section].loc, false, curr_section};
	symtab_index = symtab_cnt++;
}
void add_to_littab(string s){
	int val = 0, len = 0;
	// calculating operand value
	// calculating the length of the literal
	if((s[1]=='X' || s[1]=='x') && s[2]=='\''){
		len = 1;
		string operand_tail = s.substr(3, s.size()-4);
		val = hexToInt(operand_tail);
	}else if((s[1]=='c' || s[1]=='C')&& s[2]=='\''){
		len = s.size()-4;

		for(int i=3;i<s.size()-1;i++){
			val+=s[i];
			val<<=8;
		}
		val>>=8;
	}

	// add the entry to littab
	littab[littab_cnt] = {s, -1, val, len};
	littab_cnt++;
}

void print_modification_records(void){
	for(string s:modification_record){
		cout<<s<<"\n";
	}
}

void reflect_expr(string operand, int &val, bool &ref, bool &etype){
	string tmp="";
	
	if(operand == "*"){
		val = loctab[curr_section].loc;
		etype = false;
		ref = false;
		return;
	}

	bool flag = true, found = false;
	int pos = 0, neg = 0, j=0;
	if(operand[0]=='-'){
		flag = false;
		j = 1;
	}else if(operand[0]=='+'){
		j = 1;
	}

	int n = operand.size();
	for(int i=j;i<=n;i++){
		if(operand[i]=='-' || operand[i]=='+' || i==n){
			found = 0;
			for(int s = 0; s<symtab_cnt;s++){
				if(symtab[s].symbol == tmp){
					// symbol found in the symtab
					// the found symbol is an external reference
					if(symtab[s].control_section != curr_section){
						ref = true;
						break;
					}
					// if symbol found in symtab
					// also belongs to same control section. add the value to val
					found = true;
					if(flag){
						pos++;
						val+=symtab[s].addr;
					}else{
						neg++;
						val-=symtab[s].addr;
					}
					break;
				}
			}
			if(found == false){
				if(flag){
					val+=atoi(tmp.c_str());
				}else{
					val-=atoi(tmp.c_str());
				}
			}
			tmp = "";
			if(operand[i]=='+')flag = true;
			else flag = false;
		}else{
			tmp+=operand[i];
		}
	}
	if(pos==neg)etype = !ref;
	else etype = 0;
	

}

bool all_spaces(string s){
	int n=s.size();
	for(int i=0;i<n;i++){
		if(s[i]!='\t' && s[i]!=' ')return false;
	}
	return true;
}

string make6(string s){
	int n = s.size();
	string ans = s;
	while(n<6){
		ans+=' ';
		n++;
	}
	return ans;
}

void pass1(void){
	string tmp = "";
	string inst = "";
	bool xinst = false, literal = false;

	ifstream in ("input.txt");
	ofstream out ("intermediate.txt");

	// reading the first line of the input
	getline(in, inst);
	make_line(inst);
	read_instruction(inst);

	if(opcode == "START"){
		loctab[curr_section].start_addr = hexToInt(operand);
		loctab[curr_section].loc = loctab[curr_section].start_addr;
		loctab[curr_section].section = label;
		loctab_cnt++;

		out<<right<<setw(4)<<setfill('0')<<std::hex<<loctab[curr_section].loc;
		out<<sp<<inst<<"\n";

		getline(in, inst);
		make_line(inst);
		read_instruction(inst);

	}else{
		loctab[curr_section].start_addr = 0;
		loctab[curr_section].loc = 0;
	}

	while(opcode!="END"){
		if(inst[0]=='.' || all_spaces(inst)){
			out<<inst<<"\n";
			getline(in, inst);
			make_line(inst);
			read_instruction(inst);
			continue;
		}

		
		if(opcode == "EQU"){
			int val = 0;
			bool is_absolute = false, ext_ref_found = false;
			reflect_expr(operand, val, is_absolute, ext_ref_found);
			search_symtab(label);

			if(!symtab_found){
				add_to_symtab(label);
			}
			symtab[symtab_index].addr = val;
			symtab[symtab_index].type = is_absolute;

			out<<right<<setw(4)<<setfill('0')<<std::hex<<val;
			out<<sp<<inst<<"\n";

		}else if(opcode == "CSECT"){
			// storing the length of current section in the
			// len variable of loctab entry
			loctab[curr_section].len = loctab[curr_section].loc - loctab[curr_section].start_addr;

			// initializing the next control section 
			// new entry in the loctab
			loctab[loctab_cnt] = {label, 0, 0, 0};
			// len is updated later, for now it's a fill value (0)
			loctab_cnt+=1;
			curr_section++;
			out<< right<<setw(4)<<setfill('0')<<std::hex << loctab[curr_section].loc;
			out<<sp<<inst<<"\n";
		}else{
			if(label.size()){
				search_symtab(label);
				if(!symtab_found){
					// if not found add to symtab
					add_to_symtab(label);
				}
			}
			if(opcode[0]=='+'){
				// opcode = opcode.substr(1);
				xinst = true;
			}else{
				xinst = false;
			}
			// extended instructions handled
			// checking for operend to be a literal
			literal = false;
			if(operand[0]=='='){
				literal = true;
				search_littab(operand);
				if(!littab_found){
					add_to_littab(operand);
				}
			}

			// checking if the opcode is external definition or reference
			// updating external_symtab incase found
			if(opcode=="EXTDEF" || opcode=="EXTREF"){
				int n = operand.size();
				tmp = "";
				bool flag = false;
				for(int i=0;i<=n;i++){
					if(i<n && operand[i]!=','){
						tmp+=operand[i];
						continue;
					}
					for(int i=0;i<external_symtab_cnt;i++){
						if(external_symtab[i].symbol == tmp && external_symtab[i].control_section==curr_section){
							flag = true;
						}
					}
					if(!flag){
						external_symtab[external_symtab_cnt] = {tmp,true?opcode[3]=='D':false, curr_section};
					}
					tmp = "";
				}
				out<<sp<<sp<<inst<<"\n";
			}else if(opcode=="LTORG"){
				out<<sp<<sp<<inst<<"\n";

				// assign addresses to all the remaining literals
				for(int i=0;i<littab_cnt;i++){
					if(littab[i].addr == -1){
						littab[i].addr = loctab[curr_section].loc;
						out<<right<<setw(4)<<setfill('0')<<std::hex<<loctab[curr_section].loc;
						out<<sp<<"*";
						out<<sp<<"  "<<littab[i].literal<<"\n";

						loctab[curr_section].loc += littab[i].len;
					}
				}

			}else{
				out<<right<<setw(4)<<setfill('0')<<std::hex<<loctab[curr_section].loc;
				out<<sp<<inst<<"\n";
			}
		}
		// increase the location counter loctab[curr].loc
		bool found_opcode = optable.find(opcode)!=optable.end();
		int locctr = loctab[curr_section].loc;
		if(xinst){
			found_opcode = optable.find(opcode.substr(1))!=optable.end();
		}

		if(found_opcode && (opcode=="TIXR" || opcode=="COMPR" || opcode=="CLEAR")){
			locctr+=2;
		}else if(found_opcode && xinst){
			locctr+=4;
		}else if(found_opcode && !xinst){
			locctr+=3;
		}else if(opcode=="WORD"){
			locctr+=3;
		}else if(opcode=="RESW"){
			locctr+= 3*stoi(operand);
		}else if(opcode=="RESB"){
			locctr += stoi(operand);
		}else if(opcode=="BYTE"){
			if((operand[0]=='X'||operand[0]=='x') && operand[1] =='\''){
				locctr += 1;
			}else if((operand[0]=='c' || operand[0]=='C') && operand[1]=='\''){
				int n = operand.size();
				for(int i=2;i<n;i++){
					if(operand[i]=='\''){
						locctr+= (i-2);
						break;
					}
				}
			}
		}else{
			invalid_operation = true;
		}
		loctab[curr_section].loc = locctr;

		// read the next instruction
		getline(in, inst);
		make_line(inst);
		read_instruction(inst);
	}
	// list the last instruction
	out<<sp<<sp<<inst<<"\n";

	
	// assign addresses to all remaining literals
	for(int i=0;i<littab_cnt;i++){
		if(littab[i].addr == -1){
			littab[i].addr = loctab[curr_section].loc;
			out<<std::right<<setw(4)<<setfill('0')<<std::hex<<loctab[curr_section].loc;
			out<<sp<<"*";
			out<<sp<<"  "<<littab[i].literal<<"\n";

			loctab[curr_section].loc += littab[i].len;
		}
	}

	// length of the section - store
	loctab[curr_section].len = loctab[curr_section].loc - loctab[curr_section].start_addr;


	in.close();
	out.close();
}

void reflect_inst(string inst){
	int i=0, n = inst.size();
	locctr = hexToInt(rd_str(inst, i));
	i+=4;
	label = rd_str(inst, i);
	reach_str(inst,i);
	opcode = rd_str(inst,i);
	reach_str(inst,i);
	operand = rd_str(inst,i);

}

void pass2(void){
	ifstream in ("intermediate.txt");
	ofstream list ("listing.txt");
	ofstream obj ("object.txt");
	ofstream caret ("caret.txt");

	string inst, object_str, record = "", record_tail="", caret_str = "";

	getline(in, inst);
	make_line(inst);
	reflect_inst(inst);

	if(opcode == "START"){
		list<<inst<<"\n";

		getline(in,inst);
		make_line(inst);
		reflect_inst(inst);
	}
	obj<<"H";
	obj<<std::left<<setw(6)<<loctab[curr_section].section;
	obj<<std::right<<setw(6)<<setfill('0')<<std::hex<< loctab[curr_section].start_addr;
	obj<<std::right<<setw(6)<<setfill('0')<<std::hex<< loctab[curr_section].len <<"\n";

	caret<<"H";
	caret<<std::left<<setw(6)<<loctab[curr_section].section;
	caret<<std::right<<setw(6)<<setfill('0')<<std::hex<< loctab[curr_section].start_addr;
	caret<<std::right<<setw(6)<<setfill('0')<<std::hex<< loctab[curr_section].len <<"\n";
	
	caret<<" ^"<<right<<setw(6)<<setfill(' ')<<"^"<<right<<setw(6)<<setfill(' ')<<"^"<<"\n";

	int opcode_val, index_val, addr_val, object_val;
	while(opcode!="END"){
		opcode_val = 0;
		index_val = 0;
		addr_val = 0;
		object_val = 0;
		object_str = "";

		// cout<<right<<setw(4)<<setfill('0')<<hex<<locctr<<" "<<opcode<<"\n";

		if(inst[0]=='.'){
			list<<inst<<"\n";

			getline(in,inst);
			make_line(inst);
			reflect_inst(inst);
			continue;
		}

		if(label=="*"){

			if(record == ""){
				record = "T" + inttoHex(locctr);
			}

			search_littab(opcode);
			if(littab_found){
				object_val = littab[littab_index].operand;
			}
			int h = 2;
			if(opcode[1]=='C')h = 6;
			list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
			list<<right<<setw(h)<<setfill('0')<<hex<<object_val<<"\n";

			object_str = inttoHex(object_val);
		}else{
			int type = 0;
			if(opcode[0]=='+'){
				type = 4;
			}else if(opcode == "CLEAR" || opcode == "COMPR" || opcode == "TIXR"){
				type = 2;
			}else{
				if(optable.find(opcode)!=optable.end()){
					type = 3;
				}
			}

			switch(type){
				case 2:
				// format :: 6 bit opcode, 2 bits flag, 8 bits for registers
				if(record == ""){
					record = "T" + inttoHex(locctr);
				}
				object_val = hexToInt(optable[opcode])<<4;
				object_val += reg[operand[0]];
				object_val<<=4;
				if(operand.size()>2){
					object_val+=reg[operand[2]];
				}
				list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
				list<<right<<setw(4)<<setfill('0')<<hex<<object_val<<"\n";

				object_str = mInttoMHex(object_val);
				goto skipper;
				break;
				case 3:
				if(record == ""){
					record = "T" + inttoHex(locctr);
				}

				// format :: 6bit opcode + 6bit flags + 12 bit addresses/operands
				object_val = hexToInt(optable[opcode])<<16;
				if(operand==""){
					object_val |= (1<<16);
					object_val |= (1<<17);
				}else{
					if(operand[0]=='#'){
						// cout<<record<<" "<<opcode<<"\n";
						string tmp = operand.substr(1);
						search_symtab(tmp);
						if(symtab_found){
							object_val+=symtab[symtab_index].addr - (locctr+3);
							object_val |= (1<<16);
							object_val |= (1<<13);
						}else{
							object_val += hexToInt(tmp);
							object_val |= (1<<16);
							// set immediate flag
						}
					}else if(operand[0]=='='){
						search_littab(operand);
						if(littab_found){
							index_val = littab[littab_index].addr - (locctr+3);
							index_val &= ((1<<12)-1);
							object_val += index_val;
						}
						object_val |= (1<<17);
						object_val |= (1<<16);
						object_val |= (1<<13);
					}else if(operand[0]=='@'){
						string tmp = operand.substr(1);
						search_symtab(tmp);
						if(symtab_found){
							index_val = symtab[symtab_index].addr - (locctr+3);
							index_val &= ((1<<12)-1);
							object_val += index_val;
							object_val |= (1<<17);
							object_val |= (1<<13);
						}else{
							object_val += hexToInt(tmp);
							object_val |= (1<<17);
						}
					}else{
						search_symtab(operand);
						if(symtab_found){
							index_val = symtab[symtab_index].addr - (locctr+3);
							index_val &= ((1<<12)-1);
							object_val += index_val;
						}
						object_val |= (1<<17);
						object_val |= (1<<16);
						object_val |= (1<<13);
					}
				}
				list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
				list<<right<<setw(6)<<setfill('0')<<hex<<object_val<<"\n";

				object_str = inttoHex(object_val);
				goto skipper;
				break;
				case 4:
				// format :: 6 bit opcode + 6 bit flags + 24 bit addresses/operand
				if(record == ""){
					record = "T" + inttoHex(locctr);
				}
				string tmp1 = opcode.substr(1);

				object_val = hexToInt(optable[tmp1])<<24;
				// cout<<hex<<object_val<<" obj val f4\n";
				object_val |= (1<<25);
				object_val |= (1<<24);
				object_val |= (1<<20);
				index_val = 0;

				string mrecord = "M" + inttoHex(locctr+1) + "05+" + operand;
				if(operand.size()){
					if(operand.substr(operand.size()-2)==",X"){
						object_val |= (1<<23);
						// search_symtab(operand.substr(0,operand.size()-2));
						// if(symtab_found){
						// 	index_val = symtab[symtab_index].addr - (locctr+3);
						// 	index_val &= ((1<<12)-1);
						// 	object_val += index_val;
						// }
						mrecord = mrecord.substr(0,mrecord.size()-2);
					}else{
						search_symtab(operand);
						if(symtab_found){
							index_val+= symtab[symtab_index].addr - 0;
						}else{
							for(int i=0;i<external_symtab_cnt;i++){
								if(operand==external_symtab[i].symbol && external_symtab[i].control_section==curr_section){
									index_val = 0;
								}
							}
						}
					}

				}
				modification_record.push_back(mrecord);
				index_val &= ((1<<20)-1);
				object_val += index_val;

				list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
				list<<right<<setw(8)<<setfill('0')<<hex<<object_val<<"\n";

				object_str = bInttoBHex(object_val);
				goto skipper;
				break;
			}


			if(opcode == "CSECT"){
				if(record == ""){
					record = "T" + inttoHex(locctr);
				}
				int loctab_index = -1;
				bool loctab_found = false;

				for(int i=0;i<loctab_cnt;i++){
					if(loctab[i].section == label){
						loctab_found = true;
						loctab_index = i;
						break;
					}
				}

				if(loctab_found){
					list<<left<<setfill(' ')<<setw(40)<<inst<<"\n";
					
					record += sInttoSHex(record_tail.size()>>1);
					record += record_tail;
					if(record_tail!=""){
						obj<<record<<"\n";
						caret << record <<"\n";
						caret << caret_str << "\n";
					}

					// text records printing done
					// modification records should be printed

					string mod_caret_str = " ^     ^ ^";
					if(start_mod==-1)start_mod++;
					int modification_size = modification_record.size();
					while(start_mod<modification_size){
						obj<<modification_record[start_mod]<<"\n";
						caret<<modification_record[start_mod]<<"\n";
						caret<<mod_caret_str<<"\n";
						start_mod++;
					}

					if(!curr_section){
						obj<<"E";
						obj<<right<<setw(6)<<setfill('0')<<hex<<loctab[loctab_index].start_addr;
						obj<<"\n\n";

						caret<<"E";
						caret<<right<<setw(6)<<setfill('0')<<hex<<loctab[loctab_index].start_addr;
						caret<<"\n";
						caret<<" ^";
						caret<<"\n\n";
					}else{
						obj<<"E\n\n";

						caret<<"E\n\n";
					}

					record = "";
					record_tail = "";

					locctr = loctab[loctab_index].start_addr;
					curr_section++;
				}
				obj<<"H";
				obj<<left<<setw(6)<<setfill(' ')<<loctab[curr_section].section;
				obj<<right<<setw(6)<<setfill('0')<<loctab[curr_section].start_addr;
				obj<<right<<setw(6)<<setfill('0')<<loctab[curr_section].len;
				obj<<"\n";

				caret<<"H";
				caret<<left<<setw(6)<<setfill(' ')<<loctab[curr_section].section;
				caret<<right<<setw(6)<<setfill('0')<<loctab[curr_section].start_addr;
				caret<<right<<setw(6)<<setfill('0')<<loctab[curr_section].len;
				caret<<"\n";

				caret<<" ^     ^     ^\n";
			}else if(opcode == "WORD"){
				if(record == ""){
					record = "T" + inttoHex(locctr);
				}
				int val = 0;
				bool is_absolute = false, ext_ref_found = false;
				reflect_expr(operand, val, is_absolute, ext_ref_found);

				string mrecord = "";
				int j = 0;
				int sign_int = 1, n = operand.size();
				if(operand[j]=='-'){
					sign_int = -1;
					j++;
				}else if(operand[j]=='+'){
					j++;
				}

				string tmp = "";
				for(int i=j;i<=n;i++){
					if(operand[i]=='+' || operand[i]=='-' || i==n){
						bool found = false;
						// cout<<tmp<<"\n\n";
						for(int s = 0; s<symtab_cnt;s++){
							// cout<<symtab[s].symbol<<" "<<symtab[s].control_section<<"\n";
							if(symtab[s].symbol == tmp && symtab[s].control_section != curr_section){
								mrecord = "M"+inttoHex(locctr)+"06";
								mrecord += (sign_int==1)?"+":"-";
								mrecord += tmp;
								// cout<<mrecord<<"\n";
								modification_record.push_back(mrecord);
								tmp = "";
								found = true;
								
							}
						}
						if(i!=n){
							sign_int = (operand[i]=='+')?1:-1;
						}
						if(!found){
							tmp = "";
						}

					}else{
						tmp+=operand[i];
					}
				}

				// print_modification_records();

				index_val = val;
				object_val += index_val;
				list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
				list<<right<<setw(6)<<setfill('0')<<hex<<object_val<<"\n";

				object_str = inttoHex(object_val);
			}else if(opcode == "BYTE"){
				if(record == ""){
					record = "T" + inttoHex(locctr);
				}
				object_val = 0;
				string s = operand;

				int val = 0;
				if((s[0]=='X' || s[0]=='x') && s[1]=='\''){
					string operand_tail = s.substr(2, s.size()-3);
					val = hexToInt(operand_tail);

					object_val = val;
					list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
					list<<right<<setw(2)<<setfill('0')<<hex<<object_val<<"\n";
				}else if((s[0]=='c' || s[0]=='C')&& s[1]=='\''){
					for(int i=2;i<s.size()-1;i++){
						val+=s[i];
						val<<=8;
					}
					val>>=8;

					object_val = val;
					list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
					list<<right<<setw(2)<<setfill('0')<<hex<<object_val<<"\n";
				}
				object_str = sInttoSHex(object_val);

			}else{
				if(opcode == "EXTREF" || opcode == "EXTDEF" || opcode == "LTORG"){
					list<<sp<<sp<<inst<<"\n";	

					// object file
					if(opcode == "EXTDEF"){
						// define record
						// format :
						//    D[2-7 name][8-13 address][repeat]
						// 
						string drecord = "D", tmp = "", dcaret_str = " ^";
						int operand_size = operand.size();
						for(int i=0;i<=operand_size;i++){
							if(operand[i]==',' || i==operand_size){
								search_symtab(tmp);
								if(symtab_found){
									drecord += make6(symtab[symtab_index].symbol);
									drecord += inttoHex(symtab[symtab_index].addr);
									if(i!=operand_size){
										dcaret_str += "     ^     ^";
									}else{
										dcaret_str += "     ^";
									}

								}
								tmp = "";
							}else{
								tmp+=operand[i];
							}
						}
						obj<<drecord<<"\n";
						caret<<drecord<<"\n";
						caret<< dcaret_str<<"\n";
					}else if(opcode == "EXTREF"){
						// refer record
						// format ::
						//     R[2-7 name][repeat]
						string rrecord = "R", tmp = "", rcaret_str = " ^";
						int operand_size = operand.size();
						for(int i=0;i<=operand_size;i++){
							if(operand[i]==',' || i==operand_size){
								rrecord += make6(tmp);
								tmp = "";

								if(i!=operand_size)
								rcaret_str += "     ^";
							}else{
								tmp+=operand[i];
							}
						}
						obj<<rrecord<<"\n";
						caret <<rrecord<<"\n";
						caret<<rcaret_str<<"\n";
					}

					// object text records
					// Break when LTORG occurs

				}else{
					list<<inst<<"\n";

					// RESB RESW EQU etc
					if(record_tail!=""){
						record += sInttoSHex(record_tail.size()>>1);
						record += record_tail;

						obj<<record<<"\n";

						caret_str = " ^     ^ ^" + caret_str.substr(0,caret_str.size()-1);
						caret<<record<<"\n";
						caret<<caret_str<<"\n";

						caret_str = "";

						record_tail = "";
						record = "";
					}
					getline(in, inst);
					make_line(inst);
					reflect_inst(inst);
					continue;
				}
			}

		}

		skipper:
		if(opcode == "EXTREF" || opcode == "EXTDEF"){

		}
		else if(object_str.size() + record_tail.size() > 60 || opcode == "LTORG"){
			record+= sInttoSHex(record_tail.size()>>1);
			record += record_tail;
			caret_str = " ^     ^ ^" + caret_str.substr(0,caret_str.size()-1);
			if(record_tail!=""){
				obj<<record<<"\n";

				caret << record <<"\n";
				caret<<caret_str<<"\n";
			}

			// cout<<hex<<locctr<<" "<<opcode <<"\n";
			record = "T" + inttoHex(locctr);
			record_tail = "";
			if(opcode == "LTORG"){
				record = "";
			}
			caret_str = "";
		}
		record_tail += object_str;
		switch(object_str.size()){
			case 2:
				caret_str+=" ^";
			break;
			case 4:
				caret_str+="   ^";
			break;
			case 6:
				caret_str+="     ^";
			break;
			case 8:
				caret_str+="       ^";
			break;
		}

		getline(in, inst);
		make_line(inst);
		reflect_inst(inst);
	}
// print the end instruction
	list<<sp<<sp<<inst<<"\n";

	// list the remaining literals in the littab 
	getline(in,inst);
	while(inst!=""){
		make_line(inst);
		reflect_inst(inst);

		int object_val = 0, index_val = 0;

		search_littab(opcode);
		if(littab_found){
			object_val = littab[littab_index].operand;
		}
		int h = 2;
		if(opcode[1]=='C')h = 6;
		list<<left<<setfill(' ')<<setw(40)<<inst<<" ";
		list<<right<<setw(h)<<setfill('0')<<hex<<object_val<<"\n";

		if(h==2){
			object_str = sInttoSHex(object_val);
		}else{
			object_str = inttoHex(object_val);
		}
		record_tail+=object_str;

		switch(object_str.size()){
			case 2:
				caret_str+=" ^";
			break;
			case 4:
				caret_str+="   ^";
			break;
			case 6:
				caret_str+="     ^";
			break;
			case 8:
				caret_str+="       ^";
			break;
		}
		getline(in, inst);
	}

	record+= sInttoSHex(record_tail.size()>>1);
	record+=record_tail;
	obj<<record<<"\n";

	caret<<record<<"\n";
	caret<<" ^     ^ ^"<<caret_str.substr(0,caret_str.size()-1)<<"\n";

	string mod_caret_str = " ^     ^ ^";
	if(start_mod==-1)start_mod++;
	int modification_size = modification_record.size();
	while(start_mod<modification_size){
		obj<<modification_record[start_mod]<<"\n";

		caret<<modification_record[start_mod]<<"\n";
		caret<<mod_caret_str<<"\n";
		start_mod++;
	}

	obj<<"E\n";
	caret<<"E\n";


	list.close();
	obj.close();
	in.close();
}



int32_t main(void){
	pass1();
	curr_section = 0;
	pass2();
	return 0;
}